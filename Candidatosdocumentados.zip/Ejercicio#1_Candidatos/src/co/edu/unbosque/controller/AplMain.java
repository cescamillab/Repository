/* Clase que pertenece al paquete controller
*/
package co.edu.unbosque.controller;
/**
 * Clase encargada de que el programa funcione 
 * 
 * @author Santiago Giraldo
 * @author Cristian Escamilla
 */
public class AplMain {

	public static void main(String[] args) {
		
		Controller c = new Controller();
		
	}
	
}
